responsive_image
==========
Yet another drupal responsive image module, with support for retina images.

Depends on jquery 1.7 or newer
